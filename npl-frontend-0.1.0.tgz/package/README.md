# @npl/frontend

A composable, OpenAPI-driven React frontend platform where UI components dynamically render based on server-defined resource definitions and action permissions.

## Features

- 🚀 **OpenAPI-First**: Generate type-safe API clients and Zod schemas from OpenAPI specs
- 🧩 **Composable Architecture**: Resource-driven UI with dynamic forms, tables, and actions
- 🔐 **Built-in Authentication**: OIDC/OAuth2 integration with react-oidc-context
- 📝 **Type Safety**: Full TypeScript support with runtime validation via Zod
- ⚡ **React Query**: Automatic caching, background updates, and optimistic UI
- 🎨 **Smart Components**: Pre-built, customizable UI components for common patterns
- 🎭 **Flexible Theming**: CSS variables, theme presets, density modes, and headless components
- 🔄 **Reference Resolution**: Protocol-aware reference types with automatic lookups
- 📦 **Zero Config**: Scaffolding tool creates a ready-to-run project in seconds

## Quick Start

### Create a New Project

```bash
npx create-npl-frontend my-app
cd my-app
npm install
```

### Configure Environment

Copy `.env.example` to `.env` and update:

```bash
cp .env.example .env
```

```env
VITE_API_BASE_URL=http://localhost:8080
VITE_OIDC_AUTHORITY=https://your-oidc-provider.com
VITE_OIDC_CLIENT_ID=your-client-id
VITE_OIDC_REDIRECT_URI=http://localhost:5173
VITE_OIDC_POST_LOGOUT_REDIRECT_URI=http://localhost:5173
```

### Generate API Client

```bash
npm run discover
npm run generate
```

This discovers OpenAPI specs and generates:
- React Query hooks for each endpoint
- TypeScript types from schemas
- Zod schemas for runtime validation
- Protocol-aware reference types

### Start Development

```bash
npm run dev
```

## Installation (Existing Project)

```bash
npm install @npl/frontend
```

### Import Styles

Import the bundled CSS in your app entry (e.g., `src/main.tsx`):

```tsx
import '@npl/frontend/styles.css';
```

Or use a theme preset:

```tsx
// Corporate theme (professional, traditional)
import '@npl/frontend/themes/corporate.css';

// Minimal theme (clean, modern)
import '@npl/frontend/themes/minimal.css';
```

**Customization options:**
- **CSS Variables**: Override color, spacing, and component tokens
- **className Props**: All components accept `className` for custom styling
- **classNames Slots**: Target specific sub-components with granular class names
- **Data Attributes**: Style components by action, state, or resource type
- **Density Modes**: Use `data-density="compact"` or `"comfortable"` wrappers
- **Headless Components**: Full UI control with `SmartTableBase`, `ActionModalBase`

See [docs/THEMING.md](docs/THEMING.md) for complete theming guide.

## Core Concepts

### Resources

Resources are the building blocks of your application. Each resource defines:
- Display names and labels
- Navigation menu configuration
- Data schema (Zod)
- API hooks (React Query)
- Table columns and detail views
- Available actions

```tsx
import { ResourceDefinition } from '@npl/frontend';
import { PackageIcon } from 'lucide-react';
import { widgetSchema } from '@gen/zod';
import { useGetWidgets, useCreateWidget } from '@gen/api/widget';

export const widgetResource: ResourceDefinition = {
  name: 'widget',
  displayName: 'Widget',
  displayNamePlural: 'Widgets',
  
  menu: {
    path: '/widgets',
    icon: PackageIcon,
    order: 1,
  },
  
  schema: widgetSchema,
  
  api: {
    list: useGetWidgets,
    create: useCreateWidget,
    // ... other hooks
  },
  
  listColumns: ['name', 'description', 'createdAt'],
};
```

### Smart Components

Pre-built components that automatically adapt to your resource definitions:

- `SmartTable` - Data table with sorting, filtering, pagination
- `SmartListView` - List view with inline actions
- `SmartDetailView` - Detail view with action buttons
- `SmartHomePage` - Landing page with resource cards
- `ActionModal` - Dynamic form for resource actions
- `ReferenceSelectField` - Dropdown for reference fields
- `ReferenceLinkField` - Navigation link for references

### OpenAPI Generation

Place OpenAPI specs in your project root with the pattern `*-openapi.yml`:

```yaml
# widget-openapi.yml
openapi: 3.0.0
info:
  title: Widget API
  version: 1.0.0
paths:
  /widgets:
    get:
      summary: List widgets
      # ...
components:
  schemas:
    Widget:
      type: object
      properties:
        id:
          type: string
          format: uuid
        name:
          type: string
```

Run generation:

```bash
npm run discover
npm run generate
```

Generated code appears in `src/gen/`:
- `src/gen/api/` - React Query hooks
- `src/gen/zod/` - Zod schemas

## Project Structure

```
my-app/
├── src/
│   ├── resources/          # Resource definitions
│   │   ├── widgets.tsx
│   │   └── index.ts        # Register all resources
│   ├── pages/              # Page components
│   ├── gen/                # Generated code (don't edit)
│   │   ├── api/
│   │   └── zod/
│   ├── lib/
│   │   ├── api-client.ts   # Axios configuration
│   │   └── auth-config.ts  # OIDC configuration
│   ├── App.tsx
│   └── main.tsx
├── openapi-specs/          # OpenAPI specification files
│   └── widget-openapi.yml
├── orval.config.dynamic.ts # Orval configuration
└── package.json
```

## API Reference

### Core Types

```tsx
import { ResourceDefinition, ActionDefinition } from '@npl/frontend';
```

### Components

```tsx
import {
  SmartTable,
  SmartListView,
  SmartDetailView,
  SmartHomePage,
  ActionModal,
  AuthGuard,
  AppLayout,
  // ...
} from '@npl/frontend';
```

### Utilities

```tsx
import {
  createApiClient,
  createAuthConfig,
  createOrvalConfig,
  discoverOpenapiSpecs,
  generateAll,
} from '@npl/frontend';
```

### Resource Registry

```tsx
import { registerResource, getResource } from '@npl/frontend';

// Register resources during app initialization
registerResource(widgetResource);

// Look up resources by name (for reference resolution)
const resource = getResource('widget');
```

## Advanced Usage

### Custom API Client

```tsx
// src/lib/api-client.ts
import { createApiClient } from '@npl/frontend';

export const { axiosInstance, customInstance } = createApiClient({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  oidcAuthority: import.meta.env.VITE_OIDC_AUTHORITY,
  oidcClientId: import.meta.env.VITE_OIDC_CLIENT_ID,
  transformDates: true,
});
```

### Custom Auth Configuration

```tsx
// src/lib/auth-config.ts
import { createAuthConfig } from '@npl/frontend';

export const oidcConfig = createAuthConfig({
  authority: import.meta.env.VITE_OIDC_AUTHORITY,
  clientId: import.meta.env.VITE_OIDC_CLIENT_ID,
  redirectUri: import.meta.env.VITE_OIDC_REDIRECT_URI,
  scope: 'openid profile email custom-scope',
});
```

### Custom Orval Configuration

```tsx
// orval.config.dynamic.ts
import { createOrvalConfig } from '@npl/frontend/orval-config-factory';

export default createOrvalConfig({
  apiClientPath: './src/lib/api-client.ts',
  prettier: true,
  mock: false,
});
```

## Documentation

- [Architecture Guide](./docs/ARCHITECTURE.md) - System design and patterns
- [Developer Guide](./docs/DEVELOPER.md) - Contributing and development setup
- [Generation System](./docs/GENERATION.md) - OpenAPI code generation details

## Examples

See the `templates/` directory for a complete working example with:
- Document management
- Car rental system
- IOU tracking
- Rental agreements

## Requirements

- React 18+ or 19+
- Node.js 18+
- TypeScript 5+

## License

MIT

## Contributing

Contributions welcome! See [DEVELOPER.md](./docs/DEVELOPER.md) for development setup.

## Support

- [GitHub Issues](https://github.com/your-org/npl-frontend/issues)
- [Documentation](https://github.com/your-org/npl-frontend/tree/main/docs)
