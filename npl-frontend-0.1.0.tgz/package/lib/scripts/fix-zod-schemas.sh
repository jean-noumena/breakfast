#!/bin/bash

set -e

# Accept GEN_PATH environment variable or use default
GEN_PATH="${GEN_PATH:-./src/gen}"
SCHEMA_DIR="${GEN_PATH}/zod"
CONFIG_FILE="openapi-specs.json"

if [ ! -f "$CONFIG_FILE" ]; then
  echo "❌ Error: $CONFIG_FILE not found. Run 'npm run discover' first."
  exit 1
fi

echo "🔧 Fixing generated Zod schemas..."

# Read spec files from config using jq (or fallback to basic parsing)
if command -v jq &> /dev/null; then
  # Use jq for robust JSON parsing
  SCHEMA_FILES=$(jq -r '.specs[].zodPath' "$CONFIG_FILE")
else
  # Fallback: basic grep parsing
  SCHEMA_FILES=$(grep -o '"zodPath": "[^"]*"' "$CONFIG_FILE" | cut -d'"' -f4)
fi

for SCHEMA_FILE in $SCHEMA_FILES; do
  if [ ! -f "$SCHEMA_FILE" ]; then
    echo "   ⚠️  Skipping $SCHEMA_FILE (not found)"
    continue
  fi
  
  echo "   Processing $SCHEMA_FILE..."

  # Step 1: Remove Zodios client code (endpoints and api exports)
  # Find the line with "const endpoints" and delete from there to end
  line=$(grep -n "^const endpoints" "$SCHEMA_FILE" 2>/dev/null | head -1 | cut -d: -f1)
  if [ ! -z "$line" ]; then
    echo "      Removing Zodios client code (lines $line onwards)..."
    head -n $((line - 2)) "$SCHEMA_FILE" > "${SCHEMA_FILE}.tmp"
    mv "${SCHEMA_FILE}.tmp" "$SCHEMA_FILE"
  fi

  # Step 2: Fix imports - remove Zodios imports and ensure single Zod import
  echo "      Fixing imports..."
  # Remove all existing imports (with fallback for Linux)
  sed -i '' '/^import.*@zodios\/core/d' "$SCHEMA_FILE" 2>/dev/null || sed -i '/^import.*@zodios\/core/d' "$SCHEMA_FILE"
  sed -i '' '/^import.*zod/d' "$SCHEMA_FILE" 2>/dev/null || sed -i '/^import.*zod/d' "$SCHEMA_FILE"

  # Add single correct import at the top
  echo 'import { z } from "zod";
' | cat - "$SCHEMA_FILE" > "${SCHEMA_FILE}.tmp"
  mv "${SCHEMA_FILE}.tmp" "$SCHEMA_FILE"

  # Step 3: Fix z.record() for Zod v4 (requires two arguments)
  echo "      Updating z.record() calls for Zod v4..."
  sed -i '' 's/z\.record(z\.array(z\.string()))/z.record(z.string(), z.array(z.string()))/g' "$SCHEMA_FILE" 2>/dev/null || \
    sed -i 's/z\.record(z\.array(z\.string()))/z.record(z.string(), z.array(z.string()))/g' "$SCHEMA_FILE"

  # Step 4: Remove any duplicate blank lines at the top
  sed -i '' '1{/^$/d;}' "$SCHEMA_FILE" 2>/dev/null || sed -i '1{/^$/d;}' "$SCHEMA_FILE"
done

# Step 5: Create barrel files for easier imports
echo "   Creating barrel files..."

# Create API barrel file
if command -v jq &> /dev/null; then
  # Generate exports with sanitized names (replace . with _)
  {
    echo "// Auto-generated barrel file for API clients"
    echo "// Re-export all API clients from different OpenAPI specs"
    echo ""
    jq -r '.specs[] | "export * as \((.key | gsub("\\."; "")) + "Api") from '"'"'./\(.targetDir)'"'"';"' "$CONFIG_FILE"
  } > "src/gen/api/index.ts"
else
  # Fallback without jq
  cat > "src/gen/api/index.ts" << EOF
// Auto-generated barrel file for API clients
// Re-export all API clients from different OpenAPI specs
// Run 'npm run discover' to regenerate exports
EOF
fi

# Create Zod barrel file  
if command -v jq &> /dev/null; then
  {
    echo "// Auto-generated barrel file for Zod schemas"
    echo "// Re-export all schemas from different OpenAPI specs"
    echo ""
    jq -r '.specs[] | "export * as \((.key | gsub("\\."; "")) + "Schemas") from '"'"'./\(.targetDir)'"'"';"' "$CONFIG_FILE"
  } > "$SCHEMA_DIR/index.ts"
else
  ZOD_EXPORTS="// Run 'npm run discover' to regenerate exports"
  cat > "$SCHEMA_DIR/index.ts" << EOF
// Auto-generated barrel file for Zod schemas
// Re-export all schemas from different OpenAPI specs

$ZOD_EXPORTS
EOF
fi

# Step 6: Create per-package barrel files for API directories
echo "   Creating per-package barrel files..."

if command -v jq &> /dev/null; then
  GEN_API_DIR="src/gen/api"
  
  # Get all specs and process each one
  jq -c '.specs[]' "$CONFIG_FILE" | while read -r spec; do
    key=$(echo "$spec" | jq -r '.key')
    targetDir=$(echo "$spec" | jq -r '.targetDir')
    package_dir="$GEN_API_DIR/$targetDir"
    
    if [ ! -d "$package_dir" ]; then
      echo "      ⚠️  Skipping $targetDir (directory not found)"
      continue
    fi
    
    # Determine the package name for display (convert dots to spaces for readability)
    display_name=$(echo "$key" | tr '.' ' ')
    
    # Build exports based on what files exist
    exports=""
    
    # Check for tags-split mode: default/default.ts
    if [ -f "$package_dir/default/default.ts" ]; then
      exports="${exports}export * from './default/default';\n"
    fi
    
    # Check for split mode: {key}.ts
    if [ -f "$package_dir/${key}.ts" ]; then
      exports="${exports}export * from './${key}';\n"
    fi
    
    # Check for schemas file (both modes)
    if [ -f "$package_dir/${key}.schemas.ts" ]; then
      exports="${exports}export * from './${key}.schemas';\n"
    fi
    
    # Only create index.ts if we found exports
    if [ ! -z "$exports" ]; then
      echo "      Creating index.ts for $targetDir"
      {
        echo "// Auto-generated barrel file for $display_name API"
        echo -e "$exports"
      } > "$package_dir/index.ts"
    fi
  done
  
  # Create per-package barrel files for Zod directories (if they exist as directories)
  if [ -d "$SCHEMA_DIR" ]; then
    for zod_dir in "$SCHEMA_DIR"/*/ ; do
      if [ -d "$zod_dir" ]; then
        dir_name=$(basename "$zod_dir")
        display_name=$(echo "$dir_name" | tr '.' ' ')
        
        # Find all .ts files (excluding index.ts itself)
        exports=""
        for ts_file in "$zod_dir"/*.ts; do
          if [ -f "$ts_file" ] && [ "$(basename "$ts_file")" != "index.ts" ]; then
            file_name=$(basename "$ts_file" .ts)
            exports="${exports}export * from './${file_name}';\n"
          fi
        done
        
        if [ ! -z "$exports" ]; then
          echo "      Creating index.ts for zod/$dir_name"
          {
            echo "// Auto-generated barrel file for $display_name schemas"
            echo -e "$exports"
          } > "$zod_dir/index.ts"
        fi
      fi
    done
  fi
fi

echo "✅ All Zod schemas fixed successfully!"