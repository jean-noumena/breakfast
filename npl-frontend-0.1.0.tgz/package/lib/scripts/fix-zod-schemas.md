# Post-Generation Cleanup Script

This script automatically fixes compatibility issues with the generated Zod schemas.

## Issue

`openapi-zod-client` generates code that includes:
1. Zodios client imports and code (we only need pure Zod schemas)
2. `z.record()` with one argument (Zod v4 requires two arguments)
3. Extra endpoints and API client exports

## Solution

The script is **automatically run** after `npm run generate:dynamic` via the generation process.

### What the script does:

1. **Removes Zodios client code** - Deletes `const endpoints` and everything after (API client exports)
2. **Fixes imports** - Removes Zodios imports, ensures single `import { z } from "zod";`
3. **Updates z.record() calls** - Converts `z.record(z.array(...))` to `z.record(z.string(), z.array(...))`
4. **Cleans up formatting** - Removes duplicate blank lines

### Manual execution (if needed):

```bash
npm run fix:zod
```

Or directly:

```bash
bash scripts/fix-zod-schemas.sh
```

## Result

After running, `src/gen/zod/schemas.ts` contains only:
- Single Zod import
- Type definitions
- Zod schema validators
- Exported `schemas` object

No Zodios dependencies or client code!
