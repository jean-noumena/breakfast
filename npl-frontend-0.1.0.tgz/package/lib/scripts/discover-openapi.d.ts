/**
 * Discovers OpenAPI specification files in the project
 */
export function discoverOpenapiSpecs(options?: {
  root?: string;
  configFile?: string;
}): Promise<Record<string, string>>;
