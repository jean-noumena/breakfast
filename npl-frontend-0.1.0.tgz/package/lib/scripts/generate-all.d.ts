/**
 * Generates all API clients and Zod schemas from OpenAPI specifications
 */
export function generateAll(options?: {
  root?: string;
  configFile?: string;
  apiClientPath?: string;
  customInstanceName?: string;
  mock?: boolean;
}): Promise<void>;
