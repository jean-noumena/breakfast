import { createOrvalConfig } from '@npl/frontend/orval-config-factory';

// Alternative configuration that imports customInstance directly from @npl/frontend
// This avoids needing local src/lib files
export default createOrvalConfig({
  apiClientPath: '@npl/frontend',
  customInstanceName: 'customInstance',
  prettier: true,
});
