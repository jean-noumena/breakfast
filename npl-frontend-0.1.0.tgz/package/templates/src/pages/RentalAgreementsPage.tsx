/**
 * RentalAgreementsPage
 * 
 * Demonstrates the Composable Frontend Platform using Smart components.
 * This page shows how SmartListView and SmartDetailView eliminate boilerplate.
 * 
 * Routing:
 * - /rental-agreements - Table view (list of rental agreements)
 * - /rental-agreements/:id - Detail view (single rental agreement)
 */

import { Routes, Route, useParams } from 'react-router-dom';
import { SmartListView, SmartDetailView, StateBadge, PartiesDisplay } from '@npl/frontend';
import { RentalAgreementResource } from '@resources';

/**
 * RentalAgreementListView - Table view using SmartListView
 */
function RentalAgreementListView() {
  return (
    <SmartListView
      resource={RentalAgreementResource}
      subtitle="Manage Rental Agreements - Server-driven UI powered by OpenAPI spec"
      pageSize={10}
      className="rental-agreements-page"
    />
  );
}

/**
 * RentalAgreementDetailView - Detail view using SmartDetailView
 */
function RentalAgreementDetailView() {
  const params = useParams<{ id: string }>();

  return (
    <SmartDetailView
      resource={RentalAgreementResource}
      entityId={params.id!}
      subtitle="Rental Agreement Details - Server-driven UI powered by OpenAPI spec"
      fieldRenderers={{
        // Use StateBadge component for state field
        '@state': (value) => <StateBadge state={value as string} />,
        // Use PartiesDisplay component for parties field
        '@parties': (value) => <PartiesDisplay parties={value} mode="full" />,
        // Format currency values
        'terms.dailyRate': (value) => `$${(value as number).toFixed(2)}`,
        'terms.securityDeposit': (value) => `$${(value as number).toFixed(2)}`,
        // Format dates (now Date objects thanks to automatic transformation)
        'terms.startDate': (value) => (value instanceof Date ? value.toLocaleDateString() : String(value)),
        'terms.endDate': (value) => (value instanceof Date ? value.toLocaleDateString() : String(value)),
      }}
      className="rental-agreements-page"
    />
  );
}

/**
 * RentalAgreementsPage - Main page component with routing
 */
export function RentalAgreementsPage() {
  return (
    <Routes>
      <Route index element={<RentalAgreementListView />} />
      <Route path=":id" element={<RentalAgreementDetailView />} />
    </Routes>
  );
}
