/**
 * CarsPage
 * 
 * Demonstrates the Composable Frontend Platform using Smart components.
 * This page shows how SmartListView and SmartDetailView eliminate boilerplate.
 * 
 * Routing:
 * - /cars - Table view (list of cars)
 * - /cars/:id - Detail view (single car)
 */

import { Routes, Route, useParams } from 'react-router-dom';
import { SmartListView, SmartDetailView, PartiesDisplay } from '@npl/frontend';
import { CarResource } from '@resources';

/**
 * CarListView - Table view using SmartListView
 */
function CarListView() {
  return (
    <SmartListView
      resource={CarResource}
      subtitle="Manage Cars - Server-driven UI powered by OpenAPI spec"
      pageSize={10}
      className="cars-page"
    />
  );
}

/**
 * CarDetailView - Detail view using SmartDetailView
 */
function CarDetailView() {
  const params = useParams<{ id: string }>();

  return (
    <SmartDetailView
      resource={CarResource}
      entityId={params.id!}
      subtitle="Car Details - Server-driven UI powered by OpenAPI spec"
      fieldRenderers={{
        // Use PartiesDisplay component for parties field
        '@parties': (value) => <PartiesDisplay parties={value} mode="full" />,
        // Render color with color swatch
        'color': (value) => (
          <span style={{ 
            display: 'inline-flex', 
            alignItems: 'center', 
            gap: '8px',
            fontSize: '16px',
          }}>
            <span style={{
              width: '24px',
              height: '24px',
              borderRadius: '50%',
              backgroundColor: value as string,
              border: '2px solid #ccc',
            }} />
            {value as string}
          </span>
        ),
      }}
      className="cars-page"
    />
  );
}

/**
 * CarsPage - Main page component with routing
 */
export function CarsPage() {
  return (
    <Routes>
      <Route index element={<CarListView />} />
      <Route path=":id" element={<CarDetailView />} />
    </Routes>
  );
}
