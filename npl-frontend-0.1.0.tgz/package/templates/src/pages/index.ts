/**
 * Pages Barrel Export
 */

export { DocumentsPage } from './DocumentsPage';
export { CarsPage } from './CarsPage';
export { IousPage } from './IousPage';
export { RentalAgreementsPage } from './RentalAgreementsPage';
export { HomePage } from './HomePage';
