/**
 * IousPage
 * 
 * Demonstrates the Composable Frontend Platform using Smart components.
 * This page shows how SmartListView and SmartDetailView eliminate boilerplate.
 * 
 * Routing:
 * - /ious - Table view (list of IOUs)
 * - /ious/:id - Detail view (single IOU)
 */

import { Routes, Route, useParams } from 'react-router-dom';
import { SmartListView, SmartDetailView, StateBadge, PartiesDisplay } from '@npl/frontend';
import { IouResource } from '@resources';
import { useGetIouList } from '@gen/api/objects.iou/objects.iou';
import { useAuth } from 'react-oidc-context';
import type { Iou } from '@gen/api/objects.iou/objects.iou.schemas';
import './IousPage.css';

/**
 * Simple Donut Chart Component using SVG circles
 */
function DonutChart({ data }: { data: Array<{ label: string; value: number; color: string }> }) {
  const total = data.reduce((sum, item) => sum + item.value, 0);
  
  if (total === 0) {
    return <div className="chart-empty">No data</div>;
  }

  const size = 140;
  const strokeWidth = 30;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const center = size / 2;

  let accumulatedPercentage = 0;

  return (
    <div className="donut-chart-container">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {data.map((item, index) => {
          const percentage = (item.value / total) * 100;
          const strokeDasharray = `${(percentage / 100) * circumference} ${circumference}`;
          const rotation = -90 + (accumulatedPercentage / 100) * 360;
          accumulatedPercentage += percentage;
          
          return (
            <circle
              key={index}
              cx={center}
              cy={center}
              r={radius}
              fill="transparent"
              stroke={item.color}
              strokeWidth={strokeWidth}
              strokeDasharray={strokeDasharray}
              strokeDashoffset={0}
              transform={`rotate(${rotation} ${center} ${center})`}
              style={{ transition: 'stroke-dasharray 0.3s ease' }}
            >
              <title>{`${item.label}: ${item.value} (${percentage.toFixed(1)}%)`}</title>
            </circle>
          );
        })}
        <text
          x={center}
          y={center}
          textAnchor="middle"
          dominantBaseline="middle"
          fontSize="24"
          fontWeight="bold"
          fill="#111827"
        >
          {total}
        </text>
      </svg>
      <div className="chart-legend">
        {data.map((item, index) => {
          const percentage = ((item.value / total) * 100).toFixed(1);
          return (
            <div key={index} className="legend-item">
              <span className="legend-color" style={{ backgroundColor: item.color }}></span>
              <span className="legend-label">{item.label}: {item.value} ({percentage}%)</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/**
 * IOU Summary Header Component
 */
function IouSummaryHeader() {
  const auth = useAuth();
  const { data, isLoading, error } = useGetIouList({ page: 1, page_size: 1000 });

  if (isLoading) {
    return <div className="iou-summary-header loading">Loading statistics...</div>;
  }

  if (error || !data) {
    return <div className="iou-summary-header error">Unable to load statistics</div>;
  }

  const ious = data.items || [];

  // Calculate statistics
  const stateCount = ious.reduce((acc, iou: Iou) => {
    const state = iou['@state'];
    acc[state] = (acc[state] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const totalAmount = ious.reduce((sum, iou: Iou) => sum + (iou.forAmount || 0), 0);

  // Count IOUs where current user is the issuer
  const currentUserEmail = auth.user?.profile?.email || auth.user?.profile?.sub;
  const issuedByCurrentUser = ious.filter((iou: Iou) => {
    const issuerClaims = iou['@parties']?.issuer?.claims;
    if (!issuerClaims || !currentUserEmail) return false;
    
    // Check if current user email/sub matches any claim value
    return Object.values(issuerClaims).some((claimValues) =>
      Array.isArray(claimValues) && claimValues.includes(currentUserEmail)
    );
  }).length;

  const pieChartData = [
    { label: 'Unpaid', value: stateCount.unpaid || 0, color: '#f59e0b' },
    { label: 'Paid', value: stateCount.paid || 0, color: '#10b981' },
    { label: 'Forgiven', value: stateCount.forgiven || 0, color: '#6366f1' },
  ].filter(item => item.value > 0);

  return (
    <div className="iou-summary-header">
      <div className="summary-card">
        <h3>IOUs by State</h3>
        <DonutChart data={pieChartData} />
      </div>
      
      <div className="summary-card">
        <h3>Total Amount</h3>
        <div className="summary-value">${totalAmount.toFixed(2)}</div>
        <div className="summary-subtitle">Total across all IOUs</div>
      </div>
      
      <div className="summary-card">
        <h3>Issued by Me</h3>
        <div className="summary-value">{issuedByCurrentUser}</div>
        <div className="summary-subtitle">IOUs you issued</div>
      </div>
    </div>
  );
}

/**
 * IouListView - Table view using SmartListView
 */
function IouListView() {
  return (
    <>
      <IouSummaryHeader />
      <SmartListView
        resource={IouResource}
        subtitle="Manage IOUs - Server-driven UI powered by OpenAPI spec"
        pageSize={10}
        className="ious-page"
      />
    </>
  );
}

/**
 * IouDetailView - Detail view using SmartDetailView
 */
function IouDetailView() {
  const params = useParams<{ id: string }>();

  return (
    <SmartDetailView
      resource={IouResource}
      entityId={params.id!}
      subtitle="IOU Details - Server-driven UI powered by OpenAPI spec"
      fieldRenderers={{
        // Use StateBadge component for state field
        '@state': (value) => <StateBadge state={value as string} />,
        // Use PartiesDisplay component for parties field
        '@parties': (value) => <PartiesDisplay parties={value} mode="full" />,
        // Format the amount
        'forAmount': (value) => `$${(value as number).toFixed(2)}`,
      }}
      className="ious-page"
    />
  );
}

/**
 * IousPage - Main page component with routing
 */
export function IousPage() {
  return (
    <Routes>
      <Route index element={<IouListView />} />
      <Route path=":id" element={<IouDetailView />} />
    </Routes>
  );
}
