/**
 * OIDC Authentication Configuration
 * 
 * Configures the OpenID Connect client for authentication.
 * The OIDC provider is expected to be running at http://localhost:11000
 */

import type { AuthProviderProps } from 'react-oidc-context';

export interface AuthConfigOptions {
  /**
   * OIDC authority URL (default: import.meta.env.VITE_OIDC_AUTHORITY || 'http://localhost:11000')
   */
  authority?: string;
  
  /**
   * OIDC client ID (default: import.meta.env.VITE_OIDC_CLIENT_ID || 'npl-frontend')
   */
  clientId?: string;
  
  /**
   * Redirect URI after login (default: import.meta.env.VITE_OIDC_REDIRECT_URI || window.location.origin)
   */
  redirectUri?: string;
  
  /**
   * Redirect URI after logout (default: import.meta.env.VITE_OIDC_POST_LOGOUT_REDIRECT_URI || window.location.origin)
   */
  postLogoutRedirectUri?: string;
  
  /**
   * OIDC scopes to request (default: 'openid profile email')
   */
  scope?: string;
  
  /**
   * Automatically renew tokens silently (default: true)
   */
  automaticSilentRenew?: boolean;
  
  /**
   * Load user info after authentication (default: true)
   */
  loadUserInfo?: boolean;
}

/**
 * Create OIDC authentication configuration
 * 
 * @param options - Auth configuration options
 * @returns AuthProviderProps for react-oidc-context
 */
export function createAuthConfig(options: AuthConfigOptions = {}): AuthProviderProps {
  const {
    authority = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_OIDC_AUTHORITY) || 'http://localhost:11000',
    clientId = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_OIDC_CLIENT_ID) || 'npl-frontend',
    redirectUri = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_OIDC_REDIRECT_URI) || (typeof window !== 'undefined' ? window.location.origin : 'http://localhost:5173'),
    postLogoutRedirectUri = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_OIDC_POST_LOGOUT_REDIRECT_URI) || (typeof window !== 'undefined' ? window.location.origin : 'http://localhost:5173'),
    scope = 'openid profile email',
    automaticSilentRenew = true,
    loadUserInfo = true,
  } = options;

  return {
    authority,
    client_id: clientId,
    redirect_uri: redirectUri,
    post_logout_redirect_uri: postLogoutRedirectUri,
    
    // Response type for authorization code flow with PKCE
    response_type: 'code',
    
    // Scopes to request
    scope,
    
    // Automatically sign in if there's a valid session
    automaticSilentRenew,
    
    // Load user info after authentication
    loadUserInfo,
    
    // Callback after user is loaded
    onSigninCallback: () => {
      // Remove the code and state from the URL after successful login
      if (typeof window !== 'undefined') {
        window.history.replaceState({}, document.title, window.location.pathname);
      }
    },
  };
}

// Default configuration for backwards compatibility
const OIDC_AUTHORITY = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_OIDC_AUTHORITY) || 'http://localhost:11000';
const OIDC_CLIENT_ID = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_OIDC_CLIENT_ID) || 'npl-frontend';
const OIDC_REDIRECT_URI = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_OIDC_REDIRECT_URI) || (typeof window !== 'undefined' ? window.location.origin : 'http://localhost:5173');
const OIDC_POST_LOGOUT_REDIRECT_URI = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_OIDC_POST_LOGOUT_REDIRECT_URI) || (typeof window !== 'undefined' ? window.location.origin : 'http://localhost:5173');

export const oidcConfig: AuthProviderProps = {
  authority: OIDC_AUTHORITY,
  client_id: OIDC_CLIENT_ID,
  redirect_uri: OIDC_REDIRECT_URI,
  post_logout_redirect_uri: OIDC_POST_LOGOUT_REDIRECT_URI,
  
  // Response type for authorization code flow with PKCE
  response_type: 'code',
  
  // Scopes to request
  scope: 'openid profile email',
  
  // Automatically sign in if there's a valid session
  automaticSilentRenew: true,
  
  // Load user info after authentication
  loadUserInfo: true,
  
  // Callback after user is loaded
  onSigninCallback: () => {
    // Remove the code and state from the URL after successful login
    if (typeof window !== 'undefined') {
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  },
};
