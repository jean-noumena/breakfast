/**
 * Custom API Client Instance
 * 
 * This is the mutator used by Orval-generated hooks.
 * All requests go through this function, allowing centralized:
 * - Base URL configuration
 * - Authentication headers (OIDC access token)
 * - Error handling
 * - Request/response interceptors
 * - Date transformation (ISO strings -> Date objects)
 */

import type { AxiosRequestConfig, AxiosInstance } from 'axios';
import Axios from 'axios';
import { User } from 'oidc-client-ts';
import { transformDates } from './date-transformer';

export interface ApiClientConfig {
  /**
   * Base URL for API requests (default: import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api')
   */
  baseURL?: string;
  
  /**
   * OIDC authority URL for token retrieval (default: import.meta.env.VITE_OIDC_AUTHORITY)
   */
  oidcAuthority?: string;
  
  /**
   * OIDC client ID for token retrieval (default: import.meta.env.VITE_OIDC_CLIENT_ID)
   */
  oidcClientId?: string;
  
  /**
   * Whether to transform ISO date strings to Date objects (default: true)
   */
  transformDates?: boolean;
}

/**
 * Create a configured Axios instance and custom instance function for Orval
 * 
 * @param config - API client configuration
 * @returns Object with axiosInstance and customInstance
 */
export function createApiClient(config: ApiClientConfig = {}) {
  const {
    baseURL = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_API_BASE_URL) || 'http://localhost:3000/api',
    oidcAuthority = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_OIDC_AUTHORITY) || 'http://localhost:11000',
    oidcClientId = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_OIDC_CLIENT_ID) || 'npl-frontend',
    transformDates: shouldTransformDates = true,
  } = config;

  // Create Axios instance
  const axiosInstance: AxiosInstance = Axios.create({
    baseURL,
  });

  // Request interceptor: Add Authorization header with OIDC access token
  axiosInstance.interceptors.request.use(
    (config) => {
      // Get the OIDC user from session storage
      const oidcKey = `oidc.user:${oidcAuthority}:${oidcClientId}`;
      const oidcUserJson = sessionStorage.getItem(oidcKey);
      
      if (oidcUserJson) {
        try {
          const user: User = JSON.parse(oidcUserJson);
          
          if (user.access_token) {
            config.headers.Authorization = `Bearer ${user.access_token}`;
          }
        } catch (error) {
          console.error('Failed to parse OIDC user from session storage:', error);
        }
      }
      
      return config;
    },
    (error) => {
      return Promise.reject(error);
    }
  );

  // Response interceptor: Transform ISO date strings to Date objects
  if (shouldTransformDates) {
    axiosInstance.interceptors.response.use(
      (response) => {
        if (response.data) {
          response.data = transformDates(response.data);
        }
        return response;
      },
      (error) => {
        return Promise.reject(error);
      }
    );
  }

  /**
   * Custom instance function for Orval
   * 
   * This is the "mutator" that Orval uses to make requests.
   * It wraps the Axios instance and provides:
   * - Automatic authentication
   * - Date transformation
   * - Centralized error handling
   */
  async function customInstance<T>(
    config: AxiosRequestConfig,
    options?: AxiosRequestConfig,
  ): Promise<T> {
    const source = Axios.CancelToken.source();
    
    const promise = axiosInstance({
      ...config,
      ...options,
      cancelToken: source.token,
    }).then(({ data }) => data);

    // @ts-ignore
    promise.cancel = () => {
      source.cancel('Query was cancelled');
    };

    return promise;
  }

  return {
    axiosInstance,
    customInstance,
  };
}

// Create default instance
const { axiosInstance, customInstance } = createApiClient();

export { axiosInstance, customInstance };

/**
 * Error handler utility
 * 
 * Extract a user-friendly error message from an Axios error
 */
export function getErrorMessage(error: unknown): string {
  if (Axios.isAxiosError(error)) {
    if (error.response?.data?.message) {
      return error.response.data.message;
    }
    
    if (error.response?.data?.error) {
      return error.response.data.error;
    }
    
    if (error.response?.status === 401) {
      return 'Unauthorized. Please log in again.';
    }
    
    if (error.response?.status === 403) {
      return 'Forbidden. You do not have permission to perform this action.';
    }
    
    if (error.response?.status === 404) {
      return 'Resource not found.';
    }
    
    if (error.response?.status === 500) {
      return 'Internal server error. Please try again later.';
    }
    
    if (error.message) {
      return error.message;
    }
  }
  
  if (error instanceof Error) {
    return error.message;
  }
  
  return 'An unknown error occurred';
}

/**
 * Type guard for API error responses
 */
export interface ApiErrorResponse {
  message?: string;
  error?: string;
  errors?: Record<string, string[]>;
}

export function isApiErrorResponse(data: unknown): data is ApiErrorResponse {
  return (
    typeof data === 'object' &&
    data !== null &&
    ('message' in data || 'error' in data || 'errors' in data)
  );
}
