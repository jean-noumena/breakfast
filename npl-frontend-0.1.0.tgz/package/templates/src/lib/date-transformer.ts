/**
 * Date Transformer Utility
 * 
 * Automatically transforms ISO date strings to Date objects in API responses.
 * Works recursively through objects and arrays.
 * 
 * This transformer runs automatically in the Axios response interceptor,
 * converting all ISO 8601 date-time strings to JavaScript Date objects.
 * 
 * Supported formats:
 * - 2026-03-01T00:00:00Z
 * - 2026-03-01T00:00:00+01:00
 * - 2026-03-01T00:00:00.123Z
 * 
 * This eliminates the need to manually parse dates in your components.
 */

// ISO 8601 date string pattern (matches date-time and zoned-date-time formats)
const ISO_DATE_PATTERN = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?(?:Z|[+-]\d{2}:\d{2})$/;

/**
 * Check if a string is an ISO date string
 */
function isISODateString(value: string): boolean {
  return ISO_DATE_PATTERN.test(value);
}

/**
 * Recursively transform ISO date strings to Date objects in an object/array
 * 
 * @param data - The data to transform (can be object, array, or primitive)
 * @returns The transformed data with Date objects instead of date strings
 */
export function transformDates<T>(data: T): T {
  // Handle null/undefined
  if (data === null || data === undefined) {
    return data;
  }

  // Handle arrays
  if (Array.isArray(data)) {
    return data.map(item => transformDates(item)) as T;
  }

  // Handle objects
  if (typeof data === 'object') {
    const result: any = {};
    
    for (const [key, value] of Object.entries(data)) {
      // Check if the value is a date string
      if (typeof value === 'string' && isISODateString(value)) {
        result[key] = new Date(value);
      }
      // Recursively transform nested objects/arrays
      else if (value !== null && typeof value === 'object') {
        result[key] = transformDates(value);
      }
      // Keep primitive values as-is
      else {
        result[key] = value;
      }
    }
    
    return result as T;
  }

  // Return primitives unchanged
  return data;
}

/**
 * Transform dates in a single field (utility for field-specific transforms)
 */
export function transformDateField(value: unknown): Date | unknown {
  if (typeof value === 'string' && isISODateString(value)) {
    return new Date(value);
  }
  return value;
}
