/**
 * Car Resource Definition
 * 
 * This file demonstrates the "Glue Layer" - connecting generated code
 * to the core type system for Cars.
 * 
 * It defines:
 * - Actions available for cars (changeColor)
 * - Resource configuration (hooks, schemas, display metadata)
 * - Table column definitions
 * 
 * This is consumed by SmartTable and other smart components.
 */

import type { ResourceDefinition, ActionDefinition } from '@npl/frontend';
import type {
  Car,
  CarChangeColorCommand,
  CarCreate,
  GetCarListParams,
} from '@gen/api/objects.car/objects.car.schemas';
import { PartiesDisplay } from '@npl/frontend';
import { CarFront } from 'lucide-react';
import { CarsPage } from '@pages';

// Import generated React Query hooks
import {
  useGetCarList,
  useGetCarByID,
  useCreateCar,
  useCarChangeColor,
} from '@gen/api/objects.car/objects.car';

// Import generated Zod schemas
import { schemas as carSchemas } from '@gen/zod/objects.car';

/**
 * Action: Change Color
 * 
 * Allows changing the car's color via the /changeColor endpoint.
 * Server determines visibility via @actions.changeColor
 */
const changeColorAction: ActionDefinition<CarChangeColorCommand, Car> = {
  name: 'changeColor',
  label: 'Change Color',
  description: 'Change the car color',
  variant: 'primary',
  icon: 'palette',

  // Generated mutation hook from Orval
  mutationHook: useCarChangeColor,

  // Generated Zod schemas for runtime validation
  payloadSchema: carSchemas.Car_ChangeColor_Command,
  returnSchema: carSchemas.Car,

  // Form configuration
  showPayloadForm: true,
  requiresConfirmation: false,
};

/**
 * Car Resource Definition
 * 
 * This is the complete resource configuration consumed by SmartTable
 * and other components.
 */
export const CarResource: ResourceDefinition<
  Car,
  GetCarListParams,
  CarCreate
> = {
  // Resource metadata
  name: 'cars',
  displayName: 'Car',
  displayNamePlural: 'Cars',
  showActionsInListView: false, // Hide actions in list view for cleaner UI

  // Reference configuration
  referenceKey: 'Car',
  formatLabel: (car) => `${car.model} (${car.color})`,

  // Generated React Query hooks
  listHook: useGetCarList,
  detailHook: useGetCarByID,
  createHook: useCreateCar,

  // Zod schema for create payload validation
  createSchema: carSchemas.Car_Create,

  // Party-specific claim key restrictions
  // Uncomment to enforce claim key requirements for the owner party
  // party: {
  //   owner: {
  //     requiredClaimKeys: ['preferred_username', 'email'],
  //     additionalClaimKeysAllowed: false, // Only required keys allowed (default)
  //   }
  // },

  // Available actions
  // SmartTable will filter these based on entity['@actions']
  actions: [changeColorAction],

  // Table column configuration
  columns: [
    {
      key: 'id',
      label: 'ID',
      accessor: (row) => row['@id'],
      width: '280px',
    },
    {
      key: 'model',
      label: 'Model',
      accessor: (row) => row.model,
      width: '200px',
    },
    {
      key: 'color',
      label: 'Color',
      accessor: (row) => row.color,
      render: (value) => (
        <span style={{ 
          display: 'inline-flex', 
          alignItems: 'center', 
          gap: '8px' 
        }}>
          <span style={{
            width: '16px',
            height: '16px',
            borderRadius: '50%',
            backgroundColor: value as string,
            border: '1px solid #ccc',
          }} />
          {value as string}
        </span>
      ),
      width: '150px',
    },
    {
      key: 'owner',
      label: 'Owner',
      accessor: (row) => row['@parties']?.owner,
      render: (value) => (
        <PartiesDisplay 
          parties={value ? { owner: value } : null} 
          mode="compact" 
        />
      ),
      width: '200px',
    },
  ],

  // Pagination configuration
  defaultPageSize: 25,

  // Navigation menu configuration
  menu: {
    icon: CarFront,
    order: 4,
    path: '/cars',
  },

  // Page component to render for this resource
  pageComponent: CarsPage,
};
