/**
 * IOU Resource Definition
 * 
 * This file demonstrates the "Glue Layer" - connecting generated code
 * to the core type system for IOUs (I Owe You debts).
 * 
 * It defines:
 * - Actions available for IOUs (pay, forgive, getAmountOwed)
 * - Resource configuration (hooks, schemas, display metadata)
 * - Table column definitions
 * 
 * This is consumed by SmartTable and other smart components.
 */

import type { ResourceDefinition, ActionDefinition } from '@npl/frontend';
import type {
  Iou,
  IouPayCommand,
  IouCreate,
  GetIouListParams,
} from '@gen/api/objects.iou/objects.iou.schemas';
import { StateBadge, PartiesDisplay } from '@npl/frontend';
import { Receipt } from 'lucide-react';
import { IousPage } from '@pages';

// Import generated React Query hooks
import {
  useGetIouList,
  useGetIouByID,
  useCreateIou,
  useIouPay,
  useIouForgive,
  useIouGetAmountOwed,
} from '@gen/api/objects.iou/objects.iou';

// Import generated Zod schemas
import { schemas as iouSchemas } from '@gen/zod/objects.iou';

/**
 * Action: Pay IOU
 * 
 * Allows paying off an IOU amount via the /pay endpoint.
 * Server determines visibility via @actions.pay
 */
const payAction: ActionDefinition<IouPayCommand, Iou> = {
  name: 'pay',
  label: 'Pay',
  description: 'Make a payment on this IOU',
  variant: 'primary',
  icon: 'dollar-sign',

  // Generated mutation hook from Orval
  mutationHook: useIouPay,

  // Generated Zod schemas for runtime validation
  payloadSchema: iouSchemas.Iou_Pay_Command,
  returnSchema: iouSchemas.Iou,

  // Form configuration
  showPayloadForm: true,
  requiresConfirmation: false,
};

/**
 * Action: Forgive IOU
 * 
 * Forgives the debt (transitions state from unpaid -> forgiven).
 * No payload required - simple POST endpoint.
 * Server determines visibility via @actions.forgive
 */
const forgiveAction: ActionDefinition<void, Iou> = {
  name: 'forgive',
  label: 'Forgive',
  description: 'Forgive this debt',
  variant: 'success',
  icon: 'check-circle',

  // Generated mutation hook from Orval
  mutationHook: useIouForgive,

  // Return schema for response validation
  returnSchema: iouSchemas.Iou,

  // No form needed - direct action
  showPayloadForm: false,
  requiresConfirmation: true,
  confirmationMessage: 'Are you sure you want to forgive this debt?',
};

/**
 * Action: Get Amount Owed
 * 
 * Queries the current amount owed on this IOU.
 * No payload required - simple query endpoint.
 */
const getAmountOwedAction: ActionDefinition<void, number> = {
  name: 'getAmountOwed',
  label: 'Check Amount',
  description: 'Get the current amount owed',
  variant: 'secondary',
  icon: 'info',

  // Generated mutation hook from Orval
  mutationHook: useIouGetAmountOwed,

  // No form needed - direct action
  showPayloadForm: false,
  requiresConfirmation: false,
};

/**
 * IOU Resource Definition
 * 
 * This is the complete resource configuration consumed by SmartTable
 * and other components.
 */
export const IouResource: ResourceDefinition<
  Iou,
  GetIouListParams,
  IouCreate
> = {
  // Resource metadata
  name: 'ious',
  displayName: 'IOU',
  displayNamePlural: 'IOUs',

  // Reference configuration
  referenceKey: 'Iou',
  formatLabel: (iou) => `$${iou.forAmount.toFixed(2)} - ${iou['@state']}`,

  // Generated React Query hooks
  listHook: useGetIouList,
  detailHook: useGetIouByID,
  createHook: useCreateIou,

  // Zod schema for create payload validation
  createSchema: iouSchemas.Iou_Create,

  // Party-specific claim key restrictions
  // Uncomment to enforce claim key requirements for issuer and payee parties
  party: {
    issuer: {
      requiredClaimKeys: ['preferred_username'],
      additionalClaimKeysAllowed: true, // Allow additional keys beyond required
    },
    payee: {
      requiredClaimKeys: ['preferred_username', 'email'],
      additionalClaimKeysAllowed: false, // Only required keys allowed (default)
    }
  },

  // Available actions
  // SmartTable will filter these based on entity['@actions']
  actions: [payAction, forgiveAction, getAmountOwedAction],

  // Table column configuration
  columns: [
    {
      key: 'id',
      label: 'ID',
      accessor: (row) => row['@id'],
      width: '280px',
    },
    {
      key: 'forAmount',
      label: 'Amount',
      accessor: (row) => row.forAmount,
      render: (value) => `$${(value as number).toFixed(2)}`,
      width: '120px',
      align: 'right',
    },
    {
      key: 'state',
      label: 'State',
      accessor: (row) => row['@state'],
      render: (value) => <StateBadge state={value as string} />,
      width: '120px',
      align: 'center',
    },
    {
      key: 'issuer',
      label: 'Issuer',
      accessor: (row) => row['@parties']?.issuer,
      render: (value) => (
        <PartiesDisplay 
          parties={value ? { issuer: value } : null} 
          mode="compact" 
        />
      ),
      width: '150px',
    },
    {
      key: 'payee',
      label: 'Payee',
      accessor: (row) => row['@parties']?.payee,
      render: (value) => (
        <PartiesDisplay 
          parties={value ? { payee: value } : null} 
          mode="compact" 
        />
      ),
      width: '150px',
    },
  ],

  // Pagination configuration
  defaultPageSize: 25,

  // Navigation menu configuration
  menu: {
    icon: Receipt,
    order: 2,
    path: '/ious',
  },

  // Page component to render for this resource
  pageComponent: IousPage,
};
