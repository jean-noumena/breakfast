/**
 * RentalAgreement Resource Definition
 * 
 * This file demonstrates the "Glue Layer" - connecting generated code
 * to the core type system for Rental Agreements.
 * 
 * It defines:
 * - Actions available for rental agreements (payDeposit, startRental, returnCar, etc.)
 * - Resource configuration (hooks, schemas, display metadata)
 * - Table column definitions
 * 
 * This is consumed by SmartTable and other smart components.
 */

import type { ResourceDefinition, ActionDefinition } from '@npl/frontend';
import type {
  RentalAgreement,
  RentalAgreementPayDepositCommand,
  RentalAgreementStartRentalCommand,
  RentalAgreementReturnCarCommand,
  RentalAgreementMakeRentalPaymentCommand,
  RentalAgreementCancelRentalCommand,
  RentalAgreementCreate,
  GetRentalAgreementListParams,
} from '@gen/api/rentalAgreement/rentalAgreement.schemas';
import { StateBadge, PartiesDisplay } from '@npl/frontend';
import { Car } from 'lucide-react';
import { RentalAgreementsPage } from '@pages';

// Import generated React Query hooks
import {
  useGetRentalAgreementList,
  useGetRentalAgreementByID,
  useCreateRentalAgreement,
  useRentalAgreementPayDeposit,
  useRentalAgreementStartRental,
  useRentalAgreementReturnCar,
  useRentalAgreementMakeRentalPayment,
  useRentalAgreementCompleteRental,
  useRentalAgreementCancelRental,
} from '@gen/api/rentalAgreement/default/default';

// Import generated Zod schemas
import { schemas as rentalSchemas } from '@gen/zod/rentalAgreement';

/**
 * Action: Pay Deposit
 * 
 * Allows paying the security deposit for a rental agreement.
 * Server determines visibility via @actions.payDeposit
 */
const payDepositAction: ActionDefinition<RentalAgreementPayDepositCommand, RentalAgreement> = {
  name: 'payDeposit',
  label: 'Pay Deposit',
  description: 'Pay the security deposit',
  variant: 'primary',
  icon: 'dollar-sign',

  // Generated mutation hook from Orval
  mutationHook: useRentalAgreementPayDeposit,

  // Generated Zod schemas for runtime validation
  payloadSchema: rentalSchemas.RentalAgreement_PayDeposit_Command,
  returnSchema: rentalSchemas.RentalAgreement,

  // Form configuration
  showPayloadForm: true,
  requiresConfirmation: false,
};

/**
 * Action: Start Rental
 * 
 * Starts the rental period by recording the starting mileage.
 * Server determines visibility via @actions.startRental
 */
const startRentalAction: ActionDefinition<RentalAgreementStartRentalCommand, RentalAgreement> = {
  name: 'startRental',
  label: 'Start Rental',
  description: 'Begin the rental period',
  variant: 'success',
  icon: 'play',

  // Generated mutation hook from Orval
  mutationHook: useRentalAgreementStartRental,

  // Generated Zod schemas for runtime validation
  payloadSchema: rentalSchemas.RentalAgreement_StartRental_Command,
  returnSchema: rentalSchemas.RentalAgreement,

  // Form configuration
  showPayloadForm: true,
  requiresConfirmation: false,
};

/**
 * Action: Return Car
 * 
 * Processes the return of the rental car with final mileage and any damages.
 * Server determines visibility via @actions.returnCar
 */
const returnCarAction: ActionDefinition<RentalAgreementReturnCarCommand, RentalAgreement> = {
  name: 'returnCar',
  label: 'Return Car',
  description: 'Return the rental car',
  variant: 'secondary',
  icon: 'corner-down-left',

  // Generated mutation hook from Orval
  mutationHook: useRentalAgreementReturnCar,

  // Generated Zod schemas for runtime validation
  payloadSchema: rentalSchemas.RentalAgreement_ReturnCar_Command,
  returnSchema: rentalSchemas.RentalAgreement,

  // Form configuration
  showPayloadForm: true,
  requiresConfirmation: false,
};

/**
 * Action: Make Rental Payment
 * 
 * Makes a payment towards the rental fees.
 * Server determines visibility via @actions.makeRentalPayment
 */
const makePaymentAction: ActionDefinition<RentalAgreementMakeRentalPaymentCommand, RentalAgreement> = {
  name: 'makeRentalPayment',
  label: 'Make Payment',
  description: 'Make a rental payment',
  variant: 'primary',
  icon: 'credit-card',

  // Generated mutation hook from Orval
  mutationHook: useRentalAgreementMakeRentalPayment,

  // Generated Zod schemas for runtime validation
  payloadSchema: rentalSchemas.RentalAgreement_MakeRentalPayment_Command,
  returnSchema: rentalSchemas.RentalAgreement,

  // Form configuration
  showPayloadForm: true,
  requiresConfirmation: false,
};

/**
 * Action: Complete Rental
 * 
 * Completes the rental agreement after all payments are settled.
 * No payload required - simple POST endpoint.
 * Server determines visibility via @actions.completeRental
 */
const completeRentalAction: ActionDefinition<void, RentalAgreement> = {
  name: 'completeRental',
  label: 'Complete Rental',
  description: 'Complete the rental agreement',
  variant: 'success',
  icon: 'check-circle',

  // Generated mutation hook from Orval
  mutationHook: useRentalAgreementCompleteRental,

  // Return schema for response validation
  returnSchema: rentalSchemas.RentalAgreement,

  // No form needed - direct action
  showPayloadForm: false,
  requiresConfirmation: true,
  confirmationMessage: 'Are you sure you want to complete this rental?',
};

/**
 * Action: Cancel Rental
 * 
 * Cancels the rental agreement with a specified refund percentage.
 * Server determines visibility via @actions.cancelRental
 */
const cancelRentalAction: ActionDefinition<RentalAgreementCancelRentalCommand, RentalAgreement> = {
  name: 'cancelRental',
  label: 'Cancel Rental',
  description: 'Cancel the rental agreement',
  variant: 'danger',
  icon: 'x-circle',

  // Generated mutation hook from Orval
  mutationHook: useRentalAgreementCancelRental,

  // Generated Zod schemas for runtime validation
  payloadSchema: rentalSchemas.RentalAgreement_CancelRental_Command,
  returnSchema: rentalSchemas.RentalAgreement,

  // Form configuration
  showPayloadForm: true,
  requiresConfirmation: true,
  confirmationMessage: 'Are you sure you want to cancel this rental?',
};

/**
 * RentalAgreement Resource Definition
 * 
 * This is the complete resource configuration consumed by SmartTable
 * and other components.
 */
export const RentalAgreementResource: ResourceDefinition<
  RentalAgreement,
  GetRentalAgreementListParams,
  RentalAgreementCreate
> = {
  // Resource metadata
  name: 'rentalAgreements',
  displayName: 'Rental Agreement',
  displayNamePlural: 'Rental Agreements',

  // Reference configuration
  referenceKey: 'RentalAgreement',
  formatLabel: (ra) => `${ra.carModel} (${ra.startDate} - ${ra.endDate})`,

  // Generated React Query hooks
  listHook: useGetRentalAgreementList,
  detailHook: useGetRentalAgreementByID,
  createHook: useCreateRentalAgreement,

  // Zod schema for create payload validation
  createSchema: rentalSchemas.RentalAgreement_Create,

  // Available actions
  // SmartTable will filter these based on entity['@actions']
  actions: [
    payDepositAction,
    startRentalAction,
    returnCarAction,
    makePaymentAction,
    completeRentalAction,
    cancelRentalAction,
  ],

  // Table column configuration
  columns: [
    {
      key: 'id',
      label: 'ID',
      accessor: (row) => row['@id'],
      width: '280px',
    },
    {
      key: 'car',
      label: 'Car',
      accessor: (row) => row.car,
      width: '200px',
    },
    {
      key: 'state',
      label: 'State',
      accessor: (row) => row['@state'],
      render: (value) => <StateBadge state={value as string} />,
      width: '140px',
      align: 'center',
    },
    {
      key: 'dailyRate',
      label: 'Daily Rate',
      accessor: (row) => row.terms?.dailyRate,
      render: (value) => value ? `$${(value as number).toFixed(2)}` : '-',
      width: '120px',
      align: 'right',
    },
    {
      key: 'deposit',
      label: 'Deposit',
      accessor: (row) => row.terms?.securityDeposit,
      render: (value) => value ? `$${(value as number).toFixed(2)}` : '-',
      width: '120px',
      align: 'right',
    },
    {
      key: 'renter',
      label: 'Renter',
      accessor: (row) => row['@parties']?.renter,
      render: (value) => (
        <PartiesDisplay 
          parties={value ? { renter: value } : null} 
          mode="compact" 
        />
      ),
      width: '150px',
    },
    {
      key: 'rentalCompany',
      label: 'Rental Company',
      accessor: (row) => row['@parties']?.rentalCompany,
      render: (value) => (
        <PartiesDisplay 
          parties={value ? { rentalCompany: value } : null} 
          mode="compact" 
        />
      ),
      width: '150px',
    },
  ],

  // Pagination configuration
  defaultPageSize: 25,

  // Navigation menu configuration
  menu: {
    icon: Car,
    order: 3,
    path: '/rental-agreements',
  },

  // Page component to render for this resource
  pageComponent: RentalAgreementsPage,
};
