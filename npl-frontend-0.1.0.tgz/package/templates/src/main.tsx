import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AuthProvider } from 'react-oidc-context';
import { oidcConfig } from '@npl/frontend';
import '@npl/frontend/styles.css';
import './index.css';
import App from './App.tsx';

// Create a React Query client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

// =============================================================================
// OPTION 1: OIDC Authentication (recommended)
// =============================================================================
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AuthProvider {...oidcConfig}>
      <QueryClientProvider client={queryClient}>
        <App />
      </QueryClientProvider>
    </AuthProvider>
  </StrictMode>,
);

// =============================================================================
// OPTION 2: Password Authentication (alternative)
// =============================================================================
// Uncomment to use password-based authentication instead of OIDC:
//
// import { PasswordAuthProvider, createAuthService } from '@npl/frontend';
//
// const authService = createAuthService({
//   authority: import.meta.env.VITE_OIDC_AUTHORITY || 'http://localhost:11000',
//   clientId: import.meta.env.VITE_OIDC_CLIENT_ID || 'app-client-id',
// });
//
// createRoot(document.getElementById('root')!).render(
//   <StrictMode>
//     <PasswordAuthProvider authService={authService}>
//       <QueryClientProvider client={queryClient}>
//         <App />
//       </QueryClientProvider>
//     </PasswordAuthProvider>
//   </StrictMode>,
// );
//
// Then update App.tsx to use PasswordAuthGuard instead of AuthGuard
// See docs/AUTHENTICATION.md for more details
